import random,sys,datetime,mysql.connector as con
conobj=con.connect(host="localhost",user="root",passwd="5544",database="quiz",charset="utf8")
user=[]
username=''

def play():
    curobj=conobj.cursor()
    global user
    if len(user) == 0:
        print("You are logged out, log in first to play.")
    else:
        print("==========QUIZ START==========")
        score = 0
        hour=int(datetime.datetime.now().hour)
        if hour>=0 and hour<12:
            print("!!GOOD MORNING GAMER!!,please select the category of which you would like to play the quiz")
        elif hour>=12 and hour<18:
            print("!!GOOD AFTERNOON GAMER!!,please select the category of which you would like to play the quiz")
        else:
            print("!!GOOD EVENING GAMER!!,please select the category of which you would like to play the quiz")
        print("\n1.History")
        print("2.Sports")
        print("3.Technology")
        s=int(input("\nENTER YOUR CHOICE: "))
        if s==1:
            p="select * from history;"
        elif s==2:
            p="select * from sports;"
        elif s==3:
            p="select * from technology;"
        else:
            print("INVALID CHOICE")
            print("PROGRAM TERMINATED")
            sys.exit()
        curobj.execute(p)
        t1=curobj.fetchall()
        for i in range(10):
            n=len(t1)
            ch = random.randint(0,n-1)
            print(f'\nQ{i+1}.',t1[ch][1])
            print(t1[ch][2])
            print(t1[ch][3])
            print(t1[ch][4])
            print(t1[ch][5])
            answer = input("\nEnter your answer: ")
            if answer[0].upper()==t1[ch][6][0]:
                print("\nYou are correct")
                score+=1
            else:
                print("\nYou are incorrect")
            del t1[ch]
        curobj=conobj.cursor()
        p="update user_id set SCORE={} WHERE USERNAME='{}';"
        curobj.execute(p.format(score,user[0]))
        conobj.commit()
        print("Final Score :",score)
        if score<=3:
            print("NEVER MIND,BETTER LUCK NEXT TIME")
        elif score>3 and score<7:
            print("NICE TRY GAMER")
        else:
            print("CONGRATULATIONS,YOU ARE ONE AMOMNG THE HIGHEST SCORER'S")
        
    
def quizQuestions():
    if len(user) == 0:
        print("You must first login before adding questions.")
    elif len(user) == 3:
        if user[2]=='ADMIN':
            while True:
                curobj=conobj.cursor()
                ques=input("Enter Question: ")
                option1=input("Enter option1: ")
                option2=input("Enter option2: ")
                option3=input("Enter option3: ")
                option4=input("Enter option4: ")
                corans=input("Enter correct answer: ")
                print("In which category you wan't to put this question")
                print("\n1.History")
                print("2.Sports")
                print("3.Technology")
                s=int(input("\nENTER YOUR CHOICE: "))
                if s==1:
                    s1="insert into HISTORY values({},'{}','{}','{}','{}','{}','{}');"
                    curobj.execute("select qno from history;")
                elif s==2:
                    s1="insert into sports values({},'{}','{}','{}','{}','{}','{}');"
                    curobj.execute("select qno from sports;")
                elif s==3:
                    s1="insert into technology values({},'{}','{}','{}','{}','{}','{}');"
                    curobj.execute("select qno from technology;")
                else:
                    print("INVALID CHOICE")
                t1=curobj.fetchall()
                qno=t1[-1][0]
                curobj=conobj.cursor()
                curobj.execute(s1.format(qno+1,ques,option1,option2,option3,option4,corans))
                conobj.commit()
                print("Question added successfully")
                ch=input("Do you want to continue to add more records Y/N: ")
                if ch=='n' or ch=="N":
                    break
        else:
            print("You are not allowed to add questions. Only admins are allowed to add questions.")

def update():
    if len(user) == 0:
        print("You must first login before updating questions.")
    elif len(user) == 3:
        if user[2]=='ADMIN':    
            print('''1.History
2.Sports
3.Technology''')
            ch=int(input("Enter which category question you want't to update: "))
            k=0
            if ch==1:
                curobj=conobj.cursor()
                s1="select * from history;"
                curobj.execute(s1)
                t1=curobj.fetchall()
                print("QNO--->QUESTION")
                for a in t1:
                    print(a[0],"--->",a[1])
                curobj=conobj.cursor()
                n=int(input("Enter Question number which you wan't to update"))
                for a in t1:
                    if n==a[0]:
                        k=1
                if k==1:
                    print('''1.Change Question
2.Change Option1
3.Change Option2
4.Change Option3
5.Change Option4
6.Change Correct Option''')
                    ch=int(input("Enter Your Choice"))
                    if ch==1:
                        ques=input("Enter new Question: ")
                        s1="Update history set ques='{}' where qno={}"
                        curobj.execute(s1.format(ques,n))
                    elif ch==2:
                        opt=input("Enter New Option1: ")
                        s1="Update history set option1='{}' where qno={}"
                        curobj.execute(s1.format(opt,n))
                    elif ch==3:
                        opt=input("Enter new Option2 ")
                        s1="Update history set option2='{}' where qno={}"
                        curobj.execute(s1.format(opt,n))
                    elif ch==4:
                        opt=input("Enter new Option3: ")
                        s1="Update history set option3='{}' where qno={}"
                        curobj.execute(s1.format(opt,n))
                    elif ch==5:
                        opt=input("Enter new Option4: ")
                        s1="Update history set option4='{}' where qno={}"
                        curobj.execute(s1.format(opt,n))
                    elif ch==6:
                        opt=input("Enter new correct answer: ")
                        s1="Update history set corans='{}' where qno={}"
                        curobj.execute(s1.format(opt,n))
                    else:
                        print("Invalid Choice")
                    conobj.commit()
                    print("Question updated successfully{IF YOU CHOOSE CORRECT CHOICE AMONG THE OPTIONS}")
                else:
                    print("NO SUCH QUEESTION PRESENT")


            elif ch==2:
                curobj=conobj.cursor()
                s1="select * from sports;"
                curobj.execute(s1)
                t1=curobj.fetchall()
                print("QNO--->QUESTION")
                for a in t1:
                    print(a[0],"--->",a[1])
                curobj=conobj.cursor()
                n=int(input("Enter Question number which you wan't to update"))
                for a in t1:
                    if n==a[0]:
                        k=1
                if k==1:
                    print('''1.Change Question
2.Change Option1
3.Change Option2
4.Change Option3
5.Change Option4
6.Change Correct Option''')
                    ch=int(input("Enter Your Choice"))
                    if ch==1:
                        ques=input("Enter new Question: ")
                        s1="Update sports set ques='{}' where qno={}"
                        curobj.execute(s1.format(ques,n))
                    elif ch==2:
                        opt=input("Enter New Option1: ")
                        s1="Update sports set option1='{}' where qno={}"
                        curobj.execute(s1.format(opt,n))
                    elif ch==3:
                        opt=input("Enter new Option2 ")
                        s1="Update sports set option2='{}' where qno={}"
                        curobj.execute(s1.format(opt,n))
                    elif ch==4:
                        opt=input("Enter new Option3: ")
                        s1="Update sports set option3='{}' where qno={}"
                        curobj.execute(s1.format(opt,n))
                    elif ch==5:
                        opt=input("Enter new Option4: ")
                        s1="Update sports set option4='{}' where qno={}"
                        curobj.execute(s1.format(opt,n))
                    elif ch==6:
                        opt=input("Enter new correct answer: ")
                        s1="Update sports set corans='{}' where qno={}"
                        curobj.execute(s1.format(opt,n))
                    else:
                        print("Invalid choice")
                    conobj.commit()
                    print("Question updated successfully{IF YOU CHOOSE CORRECT CHOICE AMONG THE OPTIONS}")
                else:
                    print("NO SUCH QUEESTION PRESENT")
                    
            elif ch==3:
                curobj=conobj.cursor()
                s1="select * from technology;"
                curobj.execute(s1)
                t1=curobj.fetchall()
                print("QNO--->QUESTION")
                for a in t1:
                    print(a[0],"--->",a[1])
                curobj=conobj.cursor()
                n=int(input("Enter Question number which you wan't to update"))
                for a in t1:
                    if n==a[0]:
                        k=1
                if k==1:
                    print('''1.Change Question
2.Change Option1
3.Change Option2
4.Change Option3
5.Change Option4
6.Change Correct Option''')
                    ch=int(input("Enter Your Choice"))
                    if ch==1:
                        ques=input("Enter new Question: ")
                        s1="Update technology set ques='{}' where qno={}"
                        curobj.execute(s1.format(ques,n))
                    elif ch==2:
                        opt=input("Enter New Option1: ")
                        s1="Update technology set option1='{}' where qno={}"
                        curobj.execute(s1.format(opt,n))
                    elif ch==3:
                        opt=input("Enter new Option2 ")
                        s1="Update technology set option2='{}' where qno={}"
                        curobj.execute(s1.format(opt,n))
                    elif ch==4:
                        opt=input("Enter new Option3: ")
                        s1="Update technology set option3='{}' where qno={}"
                        curobj.execute(s1.format(opt,n))
                    elif ch==5:
                        opt=input("Enter new Option4: ")
                        s1="Update technology set option4='{}' where qno={}"
                        curobj.execute(s1.format(opt,n))
                    elif ch==6:
                        opt=input("Enter new correct answer: ")
                        s1="Update technology set corans='{}' where qno={}"
                        curobj.execute(s1.format(opt,n))
                    else:
                        print("Invalid choice")
                    conobj.commit()
                    print("Question updated successfully{IF YOU CHOOSE CORRECT CHOICE AMONG THE OPTIONS}")
                else:
                    print("NO SUCH QUEESTION PRESENT")

            else:
                print("Invalid Choice")
        else:
            print("You are not allowed to update questions. Only admins are allowed to update any question.")


def delete():
    if len(user) == 0:
        print("You must first login before deleting questions.")
    elif len(user) == 3:
        if user[2]=='ADMIN':
            print('''1.History
2.Sports
3.Technology''')
            ch=int(input("Enter which category question you want't to delete"))
            k=0
            if ch==1:
                curobj=conobj.cursor()
                s1="select * from history;"
                curobj.execute(s1)
                t1=curobj.fetchall()
                print("QNO--->QUESTION")
                for a in t1:
                    print(a[0],"--->",a[1])
                curobj=conobj.cursor()
                n=int(input("Enter Question number which you wan't to delete"))
                for a in t1:
                    if n==a[0]:
                        k=1
                if k==1:
                    s1="Delete from history where qno={};"
                    curobj.execute(s1.format(n))
                    conobj.commit()
                    print("Question deleted successfully")
                else:
                    print("NO SUCH QUESTION PRESENT")

            elif ch==2:
                curobj=conobj.cursor()
                s1="select * from sports;"
                curobj.execute(s1)
                t1=curobj.fetchall()
                print("QNO--->QUESTION")
                for a in t1:
                    print(a[0],"--->",a[1])
                curobj=conobj.cursor()
                n=int(input("Enter Question number which you wan't to delete"))
                for a in t1:
                    if n==a[0]:
                        k=1
                if k==1:
                    s1="Delete from SPORTS where qno={};"
                    curobj.execute(s1.format(n))
                    conobj.commit()
                    print("Question deleted successfully")
                else:
                    print("NO SUCH QUESTION PRESENT")
            elif ch==3:
                curobj=conobj.cursor()
                s1="select * from technology;"
                curobj.execute(s1)
                t1=curobj.fetchall()
                print("QNO--->QUESTION")
                for a in t1:
                    print(a[0],"--->",a[1])
                curobj=conobj.cursor()
                n=int(input("Enter Question number which you wan't to delete"))
                for a in t1:
                    if n==a[0]:
                        k=1
                if k==1:
                    s1="Delete from TECHNOLOGY where qno={};"
                    curobj.execute(s1.format(n))
                    conobj.commit()
                    print("Question deleted successfully")
                else:
                    print("NO SUCH QUESTION PRESENT")
            else:
                print("Invalid Choice")
        else:
            print("You are not allowed to delete questions. Only admins are allowed to delete any question.")

def createAccount():
    curobj=conobj.cursor()
    print("\n==========CREATE ACCOUNT==========")
    username = input("Enter your USERNAME: ")
    password = input("Enter your PASSWORD: ")
    curobj.execute("select * from user_id;")
    t1=curobj.fetchall()
    l1=[]
    for a in t1:
        l1.append(a[0])
    if username in l1:
        print("An account of this Username already exists.\nPlease enter the login panel.")
    else:
        curobj=conobj.cursor()
        s1="insert into user_id values('{}','{}','{}',{});"
        curobj.execute(s1.format(username,password,"PLAYER",0))
        conobj.commit()
        print("Account created successfully!")
def loginAccount():
    global user
    user=[]
    print('\n==========LOGIN PANEL==========')
    curobj=conobj.cursor()
    username = input("Enter your USERNAME: ")
    password = input("Enter your PASSWORD: ")
    curobj.execute("select * from user_id;")
    t1=curobj.fetchall()
    d1={}
    for a in t1:
        d1[a[0]]=[a[1],a[2]]
    if username not in d1.keys():
        print("An account of that name doesn't exist.\nPlease create an account first.")
    elif username in d1.keys():
        if d1[username][0] != password:
            print("Your password is incorrect.\nPlease enter the correct password and try again.")
        else:
            print("You have successfully logged in.\n")
            user.append(username)
            user.append(d1[username][0])
            user.append(d1[username][1])
            print("\n====WELLCOME TO LOG IN PANEL====")
            print("\n1.CHANGE PASSWORD")
            print("OR PRESS ANY OTHER KEY TO CONTINUE")
            k=input('\nENTER YOUR CHOICE: ')
            if k=='1':
                curobj=conobj.cursor()
                new_password = input("Enter your  NEW PASSWORD: ")
                s1="update user_id set pass='{}' WHERE username='{}';"
                curobj.execute(s1.format(new_password,username))
                conobj.commit()
                print("Password Changed Succesfully")
                
def logout():
    global user
    if len(user) == 0:
            print("You are already logged out.")
    else:
        user = []
        print("You have been logged out successfully.")


def rules():
        print('''\n                                       ==============RULES==============
1.There are 3 category of questions,you will be allowed to choose any one.(uou must be log in first to play the quiz)
2. Each round consists of 10 random questions. To answer, you must press A/B/C/D (case-insensitive).
Your final score will be given at the end and will be stored in our database.
3. Each question consists of 1 point. There's no negative point for wrong answers.
4. You can create an account from ACCOUNT CREATION panel.
5. You can login using the LOGIN PANEL. Currently, the program can only login and Display  score board and change your password if you wish the same.
        ''')

def about():
        print('''\n==========ABOUT US==========
This project has been created by Priyanshu Sharma and his team members-Manan Kumar and Antriksh Nautiyal
It is a basic Python Quiz for our Final Term''')

#main
choice = 1
while choice != 10:
    print('\n=========WELCOME TO QUIZ MASTER==========')
    print('-----------------------------------------')
    print('1. PLAY QUIZ')
    print('2. ADD QUIZ QUESTIONS')
    print('3. DELETE QUIZ QUESTIONS')
    print('4. UPDATE ANY QUESTION')
    print('5. CREATE AN ACCOUNT')
    print('6. LOGIN PANEL')
    print('7. LOGOUT PANEL')
    print('8. SEE INSTRUCTIONS ON HOW TO PLAY THE GAME')
    print('9. KNOW ABOUT US')
    print('10. EXIT')
    choice = input('\nENTER YOUR CHOICE: ')
    if choice == '1':
            play()
    elif choice == '2':
            quizQuestions()
    elif choice == '3':
            delete()
    elif choice == '4':
            update()
    elif choice == '5':
            createAccount()
    elif choice == '6':
            loginAccount()
    elif choice == '7':
            logout()
    elif choice == '8':
            rules()
    elif choice == '9':
            about()
    elif choice == '10':
            break
    else:
        print('WRONG INPUT. ENTER THE CHOICE AGAIN')
conobj.close()
