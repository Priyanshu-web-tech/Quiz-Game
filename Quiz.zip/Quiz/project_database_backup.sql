-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: localhost    Database: project_quiz
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `history`
--

DROP TABLE IF EXISTS `history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `history` (
  `qno` int NOT NULL,
  `ques` char(255) DEFAULT NULL,
  `option1` char(100) DEFAULT NULL,
  `option2` char(100) DEFAULT NULL,
  `option3` char(100) DEFAULT NULL,
  `option4` char(100) DEFAULT NULL,
  `corans` char(100) DEFAULT NULL,
  PRIMARY KEY (`qno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `history`
--

LOCK TABLES `history` WRITE;
/*!40000 ALTER TABLE `history` DISABLE KEYS */;
INSERT INTO `history` VALUES (1,'When does India celebrate Independence Day?','A. 15th August','B. 2nd October','C. 26th January','D. 4th July','A. 15th August'),(2,'Where did Lord Buddha took his last breathe his?','A. Bodh Gaya','B. Rajgir','C. Sarnath','D. Kushinagar','D. Kushinagar'),(3,'Where did British first open their factories in Eartern part of India?','A.Assam','B.Orissa','C.Bihar','D.Sikkim','B.Orissa'),(4,'The theory of economic drain of India during British imperialism was propounded by whom?','A. Jawaharlal Nehru','B. Dadabhai Naoroji','C. R.C. Dutt','D. M.K. Gandhi','B. Dadabhai Naoroji'),(5,'When did Chauri-Chaura incident took place?','A. 4 February 1922','B. 4 February 1921','C. 4 March 1922','D. 4 March 1921','A. 4 February 1922'),(6,'First private train in India run between which of the two cities?','A. Delhi-Lucknow','B. Delhi-Ahmedabad','C. Both of the above route','D. None of the above','A. Delhi-Lucknow'),(7,'When did the World War 2 started?','A. 1st September 1939','B. 1st September 1938','C. 2nd September 1939','D. 2nd September 1938','A. 1st September 1939'),(8,'Upanishads are the books written on which of the following topics?','A. Religion','B. Yoga','C. Philosophy','D. Law','A. Religion'),(9,'When was the Treaty of Versailles signed?','A. June 1919','B. July 1919','C. June 1920','D. July 1920','A. June 1919'),(10,'Which of the following newspaper was started by  Annie Besant?','A. The Hindu','B. Indian Express','C. The Times of India','D. New India','D. New India'),(11,'Who formed INA(Indian National Army)?','A. Dr.Subhash Chandra Bose','B. Major Sodhi Singh','C. Mahatma Gandhi','D. Captain Mohan Singh','D. Captain Mohan Singh'),(12,'What was the role of Tatia Tope in 1857 mutiny?','A. He was commander-in-chief of the army of Nana Saheb','B. He organized Bhils of Panchamahal region against the British','C. Both A and B','D. Neither A nor B','C. Both A and B'),(13,'Which Indian revolutionary leader is known as Bagha Jatin?','A. Jatindranath Mukherjee','B. Jatindranath Bannerjee','C. Jatindranath Das','D. Jatindranath bose','A. Jatindranath Mukherjee'),(14,'The POONA ACT was an agreement between:','A. Nehru and Ambedkar','B. Gandhi and Ambedkar','C. Malaviya and Ambedkar','D. Gandhi and Nehru','B. Gandhi and Ambedkar'),(15,'Who was the prominent leader in Lucknow during the Revolt of 1857?','A. Begum Hazrat Mahal','B. Rani Laxmi Bai','C. Kuar Singh','D. Bahadur Shah Zafar','B. Rani Laxmi Bai');
/*!40000 ALTER TABLE `history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sports`
--

DROP TABLE IF EXISTS `sports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sports` (
  `qno` int NOT NULL,
  `ques` char(255) DEFAULT NULL,
  `option1` char(100) DEFAULT NULL,
  `option2` char(100) DEFAULT NULL,
  `option3` char(100) DEFAULT NULL,
  `option4` char(100) DEFAULT NULL,
  `corans` char(100) DEFAULT NULL,
  PRIMARY KEY (`qno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sports`
--

LOCK TABLES `sports` WRITE;
/*!40000 ALTER TABLE `sports` DISABLE KEYS */;
INSERT INTO `sports` VALUES (1,'Who is the first Indian woman to win an Asian Games gold in 400m run?','A. M.L. Valsamma','B. P.T. Usha','C. Kamaljit Sand','D. K.Malleshwari','B. P.T. Usha'),(2,'With which game does Davis Cup is associated?','A. Hockey','B. Table Tennis','C. Lawn Tennis','D. Polo','C. Lawn Tennis'),(3,'How many times did Geet Sethi win the IBSF World Billiards title?','A. 2','B. 3','C. 4','D. 5','B. 3'),(4,'Which batsman started his international cricketing career at the age of 16  ?','A. Suresh Raina','B. Sachin Tendulkar','C. Piyush Chawla','D. Rahul Dravid','B. Sachin Tendulkar'),(5,'In which year IPL(Indian Premier League) started?','A. 2008','B. 2009','C. 2007','D. 2010','A. 2008'),(6,'Who is the highest run scorer in one day international match?','A. Martin Guptil','B. Rohit Sharma','C. Amelia Kerr','D. Belinda Clark','B. Rohit Sharma'),(7,'Term Chinaman is related to which sports ?','A. Football','B. Hockey','C. Golf','D. Cricket','D. Cricket'),(8,'Boat race is a famous festival game of which state of INDIA?','A. Tamil Nadu','B. Uttar Pradesh','C. Karnataka','D. Kerela','D. Kerela'),(9,'India won its first Olympic hockey gold in which year ?','A. 1928','B. 1932','C. 1936','D. 1948','D. 1948'),(10,'Who was the first Indian to qualify for olympics?','A. Shiny Abraham','B. PT Usha','C. Karnam Malleshwari','D. Jyotirmony Sikdar','B. PT Usha'),(11,'The World Military Cup organized by the International Military Sports Council (CISM) involves which among the following sports?','A. Cricket','B. Football','C. Volleyball','D. Basket Ball','B. Football'),(12,'Which of the following trophy/ is not related to Cricket in India?','A. Syed Mushtaq Ali Trophy','B. Deodhar Trophy','C. Santosh Trophy','D. Duleep Trophy','C. Santosh Trophy'),(13,'Who got FIFA Best Player 2019 Award?','A. Neymar','B. L. Messi','C. C.Ronaldo','D. Luka Mordic','B. L. Messi'),(14,'As per BCCI new annual contract which of the following player is NOT in the grade A+ category?','A. Virat Kohli','B. Rohit Sharma','C. Jasprit Bumrah','D. Shikhar Dhawan','D. Shikhar Dhawan'),(15,'Who has won the Rajiv Gandhi Khel Ratna Award 2019?','A. Sakshi Malik','B. Mirabai Chanu','C. Bajrang Punia','D. None of the above','C. Bajrang Punia'),(16,'India shared gold medal with which country in the first online Chess Olympiad 2020 -','A. Russia','B. Polland','C. China','D. Korea','A. Russia'),(17,'Which of the following sports Maulana Abul Kalam Azad (MAKA) Trophy’ is given ?','A. Inter school','B. Inter state','C. Inter university','D. None of the above','C. Inter university');
/*!40000 ALTER TABLE `sports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `technology`
--

DROP TABLE IF EXISTS `technology`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `technology` (
  `qno` int NOT NULL,
  `ques` char(255) DEFAULT NULL,
  `option1` char(100) DEFAULT NULL,
  `option2` char(100) DEFAULT NULL,
  `option3` char(100) DEFAULT NULL,
  `option4` char(100) DEFAULT NULL,
  `corans` char(100) DEFAULT NULL,
  PRIMARY KEY (`qno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `technology`
--

LOCK TABLES `technology` WRITE;
/*!40000 ALTER TABLE `technology` DISABLE KEYS */;
INSERT INTO `technology` VALUES (1,'In June 2011, Shiv Nagar, a village located in Muzaffarnagar district in Uttar Pradesh, India, became X Nagar, after X had installed 15 hand pumps for drinking water. The villagers voted to name their hamlet after X to express their gratitude.What is X ?','A. Snapdeal','B. Amazon','C. Shopclues','D. Flipkart','A. Snapdeal'),(2,'The First Algotirthmic programming Language was?','A. FORTRAN','B. BASIC','C. Plankalkuel','D. C','C. Plankalkuel'),(3,'The First-ever language used on an electronic computing device is?','A. Prolong','B. C','C. Short Code','D. LISP','C. Short Code'),(4,'Which was the first Word Processing software ?','A. Abiword','B. Electric Pencil','C. Apple iWork','D. Microsoft Word','B. Electric Pencil'),(5,'Who invented python ?','A. Bjarne','B. Grace Hopper','C. John McCarthy','D. Guido Van Rossum','D. Guido Van Rossum'),(6,'The first Block Structured Language is ?','A. C','B. C++','C. FORTRAN','D. ALGOL 60','D. ALGOL 60'),(7,'When was AI first introduced ?','A. 1995','B. 1990','C. 1955','D. 1935','C. 1955'),(8,'Who is known as The Father Of AI ?','A. John McCarthy','B. Ted Codd.','C. Richard Stallman','D. Linus','A. John McCarthy'),(9,'When was first AR technology developed ?','A. 1996','B. 1949','C. 1968','D. 1974','C. 1968'),(10,'Who is the CEO of most popular smartphone brand  XIAOMI ?','A. Manu Kumar Jain','B. Lei Jun','C. Tony Chen','D. pete lau','B. Lei Jun'),(11,'In which year first first Iphone was launched ?','A. 2009','B. 2008','C. 2010','D. 2007','D. 2007'),(12,'When was the first android phone released ?','A. 2007','B. 2008','C. 2009','D. 2010','B. 2008'),(13,'Which one was the first computer virus ?','A. The FAMOUS','B. HARLIE','C. PARAM','D. CREEPER','D. CREEPER'),(14,'______Framework made cracking of vulnerabilities easy like point and click.','A. .NET','B. Metasploit','C. zeus','D. Metaspliot','B. Metasploit');
/*!40000 ALTER TABLE `technology` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_id`
--

DROP TABLE IF EXISTS `user_id`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_id` (
  `USERNAME` char(20) NOT NULL,
  `PASS` char(20) DEFAULT NULL,
  `TYPE` char(20) DEFAULT NULL,
  `SCORE` int DEFAULT '0',
  PRIMARY KEY (`USERNAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_id`
--

LOCK TABLES `user_id` WRITE;
/*!40000 ALTER TABLE `user_id` DISABLE KEYS */;
INSERT INTO `user_id` VALUES ('abc','345t','PLAYER',5),('ANTRIKSH','1234','ADMIN',0),('DEV','56TH','PLAYER',10),('DEVANSH','0000','PLAYER',8),('LUCIFER','5678','PLAYER',10),('MANAN','1234','ADMIN',2),('PRIYANSHU','PR22','ADMIN',7),('RAM','1234','PLAYER',6),('sonu','1234','PLAYER',2),('THE BEAST','HELL14','PLAYER',10),('XYZ','1234','PLAYER',2);
/*!40000 ALTER TABLE `user_id` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-04-12 22:03:44
